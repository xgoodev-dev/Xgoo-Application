function splitAddressLines(addr) {
  const raw = (addr?.address || "").trim();
  if (!raw) return { line1: "", line2: "" };
  const comma = raw.indexOf(",");
  if (comma > 8 && comma < 80) {
    return { line1: raw.slice(0, comma).trim(), line2: raw.slice(comma + 1).trim() };
  }
  if (raw.length > 80) {
    return { line1: raw.slice(0, 80).trim(), line2: raw.slice(80).trim() };
  }
  return { line1: raw, line2: "" };
}

function fillMappedSection(sectionKey, mappings) {
  let filled = 0;
  for (const [keywords, value] of mappings) {
    if (value == null || value === "") continue;
    if (fillSectionField(sectionKey, keywords, value)) filled += 1;
  }
  return filled;
}

function fillWorldFirstForm(payload) {
  const receiverLines = splitAddressLines(payload.receiver);
  const senderLines = splitAddressLines(payload.sender);
  const city = payload.receiver?.city || "";
  const origin = payload.sender?.city || "";
  const weight = payload.chargeableWeight || payload.weight;
  const pieces = payload.numberOfPieces ?? 1;

  // Column 2: To address (consignee). Never write sender into this column.
  let filled = fillMappedSection("consignee", [
    [["destination", "dest"], city],
    [["company name", "company"], payload.receiver?.name],
    [["contact name", "contact"], payload.receiver?.name],
    [["address 1", "address1", "addr 1"], receiverLines.line1 || payload.receiver?.address],
    [["address 2", "address2", "addr 2"], receiverLines.line2],
    [["pincode", "pin code", "pin"], payload.receiver?.pincode],
    [["city"], payload.receiver?.city],
    [["state"], payload.receiver?.state],
    [["mobile no", "mobile"], payload.receiver?.phone],
    [["telephone", "tel"], payload.receiver?.phone],
    [["country"], "INDIA"],
  ]);

  // Column 3: package. Skip Product / Vendor / Service lookup boxes.
  filled += fillMappedSection("services", [
    [["shipment value", "invoice value"], payload.declaredValue],
    [["pieces"], pieces],
    [["actual weight"], weight],
    [["charge weight"], weight],
  ]);

  filled += fillMappedSection("shipment", [
    [["reference"], payload.bookingNumber],
    [["content"], payload.contentDescription],
  ]);

  // Column 1: From address. Do not overwrite Client Name in Account Details.
  filled += fillMappedSection("shipper", [
    [["origin"], origin],
    [["contact name", "contact"], payload.sender?.name],
    [["address 1", "address1", "addr 1"], senderLines.line1 || payload.sender?.address],
    [["pincode", "pin code", "pin"], payload.sender?.pincode],
    [["city"], payload.sender?.city],
    [["state"], payload.sender?.state],
    [["mobile no", "mobile"], payload.sender?.phone],
    [["telephone", "tel"], payload.sender?.phone],
  ]);

  return filled;
}

var XgooWorldFirstAdapter = {
  id: "world-first",
  matches(hostname) {
    const host = (hostname || "").toLowerCase();
    return host.includes("worldfirst") || host.includes("xpresion") || host.includes("xpression");
  },
  fill(payload) {
    return fillWorldFirstForm(payload);
  },
};
